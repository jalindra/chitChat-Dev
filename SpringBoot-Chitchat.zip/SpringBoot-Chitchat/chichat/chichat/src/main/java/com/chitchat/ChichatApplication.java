package com.chitchat;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChichatApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChichatApplication.class, args);
	}

}
